clc;
clear all;
KK = [10,20];
filename2 = 'LSHADE.xlsx';
for i = 1:8
    if i == 1
       file1 = 'LSHADE_(000)';
    elseif i == 2
       file1 = 'LSHADE_(100)';
    elseif i == 3
        file1 = 'LSHADE_(010)';
    elseif i == 4
        file1 = 'LSHADE_(001)';
    elseif i == 5
        file1 = 'LSHADE_(110)';
    elseif i == 6
        file1 = 'LSHADE_(101)';
    elseif i == 7
        file1 = 'LSHADE_(011)';
    elseif i == 8
        file1 = 'LSHADE_(111)';
    end
    for j = 1:2
        for k = 1:10
            filename = [file1,'_',num2str(k),'_',num2str(KK(j)),'.txt'];
            eval('A=load(filename);');
            B = A(16,:);
            B(B<1e-8) = 0;
            MinC(k,j) = min(B);
            MenC(k,j) = mean(B);
        end
    end
    C = [MinC(1:10,1),MenC(1:10,1),MinC(1:10,2),MenC(1:10,2)];
    xlswrite(filename2,C,i);
end