clc;
clear all;
%% loading data
for i = 1:9
    if i == 1
        file_algo = 'DEDMNA.xlsx';
    elseif i == 2
        file_algo = 'APGSK_IMODE.xlsx';
    elseif i == 3
        file_algo = 'MadDE.xlsx';
    elseif i == 4
        file_algo = 'RB_IPOP_CMAES_PPMF.xlsx';
    elseif i == 5
        file_algo = 'j21.xlsx';
    elseif i == 6
        file_algo = 'NL-SHADE-RSP.xlsx';
    elseif i == 7
        file_algo = 'SOMA-CLP.xlsx';
    elseif i == 8
        file_algo = 'MLS-LSHADE.xlsx';
    elseif i == 9
        file_algo = 'LSHADE.xlsx';
    end
    for j = 1:8
        Var_name = ['A',num2str(i),'_',num2str(j)];
        eval(['A',num2str(i),'_',num2str(j), '= xlsread(file_algo,j);']);
    end
end
%% Calculation of the Score 1
%% normalization ne
for i = 1:2
    if i == 1
        l = 1;
    elseif i == 2
        l = 3;
    end
    for j = 1:8
        temp = [];
        for k = 1:9
            eval(['temp = [temp,','A',num2str(k),'_',num2str(j),'(:,',num2str(l),')];']);     
        end
        NE = temp./max(temp,[],2);
        NE(isnan(NE)) = 0;
        NEs(j,:) = sum(NE);
    end
    NEss(i,:) = sum(NEs);
end
sNE = mean(NEss)';
score1 = (1-(sNE-min(sNE))./sNE)*50;
%% Calculation of the Score 2
%% ranking
for i = 1:2
    if i == 1
        l = 2;
    elseif i == 2
        l = 4;
    end
    for j = 1:8
        temp = [];
        for k = 1:9
            eval(['temp = [temp,','A',num2str(k),'_',num2str(j),'(:,',num2str(l),')];']);     
        end
        NE = tiedrank(temp')';
        NEs(j,:) = sum(NE);
    end
    NEss(i,:) = sum(NEs);
end
sNE = mean(NEss)';
score2 = (1-(sNE-min(sNE))./sNE)*50;
%% Final Score
Score = score1+score2;
[~,ii] = sort(Score,'descend');
kk = [(1:9)',ii];
[~,jj] = sort(ii);
Rank = kk(jj,1);
%% Display
fprintf('Algorithm     Score1     Score2     Score    Rank\n');
fprintf('  E-0453     %.4f    %.4f    %.4f    %d\n',score1(1),score2(1),Score(1),Rank(1));
fprintf('  E-0336     %.4f    %.4f    %.4f    %d\n',score1(2),score2(2),Score(2),Rank(2));
fprintf('  E-0221     %.4f    %.4f    %.4f    %d\n',score1(3),score2(3),Score(3),Rank(3));
fprintf('  E-0204     %.4f    %.4f    %.4f    %d\n',score1(4),score2(4),Score(4),Rank(4));
fprintf('  E-0159     %.4f    %.4f    %.4f    %d\n',score1(5),score2(5),Score(5),Rank(5));
fprintf('  E-0125     %.4f    %.4f    %.4f    %d\n',score1(6),score2(6),Score(6),Rank(6));
fprintf('  com111     %.4f    %.4f    %.4f    %d\n',score1(7),score2(7),Score(7),Rank(7));
fprintf('  com112     %.4f    %.4f    %.4f    %d\n',score1(8),score2(8),Score(8),Rank(8));
fprintf('  com113     %.4f    %.4f    %.4f    %d\n',score1(9),score2(9),Score(9),Rank(9));