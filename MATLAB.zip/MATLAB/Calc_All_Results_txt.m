clc;
clear all;

format long;

xlsx_filename = 'Statistical_Values_EAGDE.xlsx';

All_Alg_Name={ 'DE'   };

C = [
    0 0 0;
    0 0 1;
    0 1 0;
    0 1 1;
    1 0 0;
    1 0 1;
    1 1 0;
    1 1 1;
    ];

problem_size =10;
for Alg=1:length(All_Alg_Name)
    All_Alg_Name{Alg}
    Results_000=[];
    Results_001=[];
    Results_010=[];
    Results_011=[];
    Results_100=[];
    Results_101=[];
    Results_110=[];
    Results_111=[];
    
    for func = [1:10]
        
       
        file_name=sprintf('Results\\%s_(000)_%s_%s.txt',All_Alg_Name{Alg},int2str(func),int2str(problem_size));
        outcome=load(file_name);
        outcome=outcome(end,:);
        Results_000(func,:)=[min(outcome), median(outcome),max(outcome),  mean(outcome), std(outcome)];
        
        file_name=sprintf('Results\\%s_(001)_%s_%s.txt',All_Alg_Name{Alg},int2str(func),int2str(problem_size));
        outcome=load(file_name);
        outcome=outcome(end,:);
        Results_001(func,:)=[min(outcome), median(outcome),max(outcome),  mean(outcome), std(outcome)];
        
        file_name=sprintf('Results\\%s_(010)_%s_%s.txt',All_Alg_Name{Alg},int2str(func),int2str(problem_size));
        outcome=load(file_name);
        outcome=outcome(end,:);
        Results_010(func,:)=[min(outcome), median(outcome),max(outcome),  mean(outcome), std(outcome)];
        
        file_name=sprintf('Results\\%s_(011)_%s_%s.txt',All_Alg_Name{Alg},int2str(func),int2str(problem_size));
        outcome=load(file_name);
        outcome=outcome(end,:);
        Results_011(func,:)=[min(outcome), median(outcome),max(outcome),  mean(outcome), std(outcome)];
        
        file_name=sprintf('Results\\%s_(100)_%s_%s.txt',All_Alg_Name{Alg},int2str(func),int2str(problem_size));
        outcome=load(file_name);
        outcome=outcome(end,:);
        Results_100(func,:)=[min(outcome), median(outcome),max(outcome),  mean(outcome), std(outcome)];
        
        file_name=sprintf('Results\\%s_(101)_%s_%s.txt',All_Alg_Name{Alg},int2str(func),int2str(problem_size));
        outcome=load(file_name);
        outcome=outcome(end,:);
        Results_101(func,:)=[min(outcome), median(outcome),max(outcome),  mean(outcome), std(outcome)];
        
        file_name=sprintf('Results\\%s_(110)_%s_%s.txt',All_Alg_Name{Alg},int2str(func),int2str(problem_size));
        outcome=load(file_name);
        outcome=outcome(end,:);
        Results_110(func,:)=[min(outcome), median(outcome),max(outcome),  mean(outcome), std(outcome)];
        
        file_name=sprintf('Results\\%s_(111)_%s_%s.txt',All_Alg_Name{Alg},int2str(func),int2str(problem_size));
        outcome=load(file_name);
        outcome=outcome(end,:);
        Results_111(func,:)=[min(outcome), median(outcome),max(outcome),  mean(outcome), std(outcome)];
        
        
        
        
    end %% end 1 function run
    
    All_Results=[Results_000,Results_001,Results_010,Results_011,Results_100,Results_101,Results_110,Results_111];
    All_Results(All_Results<10^-8)=0;
    
   
end
